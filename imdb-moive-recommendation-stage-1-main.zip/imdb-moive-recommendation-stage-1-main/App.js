import React from "react";
import HomeScreen from "./screens/Home";

export default function App() {
  return <HomeScreen />;
}
